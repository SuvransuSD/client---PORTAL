import React from 'react';
import SimpleImageSlider from "react-simple-image-slider";

const images = [
  { url: "images/1.jpg" },
  { url: "images/3.jpg" },
  { url: "images/4.jpg" },
];

const Dashboard = () => {
  return (
    <div>
      {/* <SimpleImageSlider
        width={896}
        height={450}
        images={images}
        showBullets={true}
        showNavs={true}
        autoPlay={true}
      /> */}
    </div>
  );
}
export default Dashboard