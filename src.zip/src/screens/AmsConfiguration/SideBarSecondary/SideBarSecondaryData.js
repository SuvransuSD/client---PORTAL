export const SideBarSecondaryData = [
    {
        title: "Key Status",
        link: "/Ams-Configuration/Key-Status"
    },
    {
        title: "RO Information",
        link: "/Ams-Configuration/Site-Information"
    },
    {
        title: "Cabinet Overview",
        link: "/Ams-Configuration/Cabinet-Overview"
    },
    // {
    //     title: "Manage Keys",
    //     link: "/Ams-Configuration/Manage-Keys"
    // },
    {
        title: "Manage Users",
        link: "/Ams-Configuration/Manage-Users"
    },
    // {
    //     title: "Manage Activities",
    //     link: "/Ams-Configuration/Manage-Activities"
    // }
    // ,
    // {
    //     title: "Manage Events",
    //     link: "/Ams-Configuration/Manage-Events"
    // }
]