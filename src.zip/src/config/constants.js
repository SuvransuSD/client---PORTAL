// export const backendurl = "http://localhost:8001/";
// export const backendurl = "http://192.168.1.7:8001/";
// export const backendurl = "http://amsenterprise.jiobp.com:443/";
// export const backendurl = "https://amsenterprise.jiobp.com/";
export const backendurl = "https://amsenterprise.jiobp.com:8001/";
// export const backendurl = "http://3.109.49.195:8002/";