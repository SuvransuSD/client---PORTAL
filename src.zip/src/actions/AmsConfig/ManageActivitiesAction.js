import axiosInstance from "../../utils/axiosInstance";
import { GET_MANAGE_ACTIVITIES_FORM, UPDATE_MANAGE_ACTIVITIES_FORM } from "../types";
import staticData from "./AmsConfig.json"
var uri = "/api/AMS_Configuration/"

// actions



export const filessssss = () => dispatch => {

}



// export const Create_manage_Activity_form = (userdata,callback) => dispatch => {

//   const MYURL = uri + `get-manage-users`;
//   axiosInstance.post(MYURL,userdata).then((result) => {
//     if (result) {
//       callback();
//       alert('created successfully');
//     }
// })
// }

// export const Update_manage_Activity_form = (userdata,callback) => dispatch => {

//   const MYURL = uri + `get-manage-users`;
//   axiosInstance.put(MYURL,userdata).then((result) => {
//     callback();
//     alert('Updated successfully');

// })
// }

// export const delete_manage_Activity_form = (userdata,callback) => dispatch => {
//   const MYURL = uri + `get-manage-users` + '/' + userdata;
//   axiosInstance.delete(MYURL,userdata).then((result) => {
//     callback();
//     alert('Deleted successfully');

// })
// }

